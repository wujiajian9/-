package Test;
import org.junit.After;
import pojo.Customer;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.*;
import org.junit.Test;
import sun.misc.Resource;
import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;

public class CustomerTest {

    private SqlSessionFactory sqlSessionFactory;
    private SqlSession sqlSession;
    @Test
    public void findWorkerByIdTest() {
        // 1.通过工具类获取SqlSession对象
        //SqlSession session = MyBatisUtils.getSession();
        String  resources="mybatis-config.xml";
        Reader reader=null;
        try {
            reader= Resources.getResourceAsReader(resources);
        }
        catch (IOException e){
            e.printStackTrace();
        }
        SqlSessionFactory sqlMapper =new SqlSessionFactoryBuilder().build(reader);
        SqlSession session = sqlMapper.openSession();
        Customer customer = session.selectOne("findById", 1);
        System.out.println("姓名:" + customer.getUsername());
        System.out.println("年龄:" + customer.getAge());
        System.out.println("职业:" + customer.getJobs());
        session.commit();
        session.close();
    }
    @Test
    public void insertWorkerByIdTest() {
        // 1.通过工具类获取SqlSession对象
        //SqlSession session = MyBatisUtils.getSession();
        String  resources="mybatis-config.xml";
        Reader reader=null;
        try {
            reader= Resources.getResourceAsReader(resources);
        }
        catch (IOException e){
            e.printStackTrace();
        }
        SqlSessionFactory sqlMapper =new SqlSessionFactoryBuilder().build(reader);
        SqlSession session = sqlMapper.openSession();
        Customer customer = new Customer();
        customer.setId(4);
        customer.setUsername("sss");
        customer.setAge(20);
        customer.setJobs("牛马");
        session.insert("addUser", customer);
        session.commit();
        session.close();
    }







}
